﻿using System;
using System.Collections.Generic;
using Pirates;
using System.Linq;

namespace MyBot
{
    public class MyBot : Pirates.IPirateBot
    {
        public void DoTurn(IPirateGame game)
        {
            // Fill your code here
        }

    }
}
