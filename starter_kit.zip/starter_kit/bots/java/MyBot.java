package bots;

import java.util.List;

import pirates.game.Direction;
import pirates.game.Island;
import pirates.game.Location;
import pirates.game.Pirate;
import pirates.game.PirateBot;
import pirates.game.PirateGame;

public class MyBot implements PirateBot {

	@Override
	public void doTurn(PirateGame game) {

        // Your code here
	}

}
